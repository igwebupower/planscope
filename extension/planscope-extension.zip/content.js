import{e as x,a as c,f as T,b as N,c as L,t as P,i as z,d as M}from"./chunks/api-CvKabz8P.js";function _(){const e=O();if(e)return console.log("[PlanScope] Extracted data from Rightmove PAGE_MODEL"),e;const n=$();if(n)return console.log("[PlanScope] Extracted data from Rightmove structured data"),n;const t=I();return t?(console.log("[PlanScope] Extracted data from Rightmove DOM"),t):(console.warn("[PlanScope] Could not extract Rightmove property data"),null)}function O(){try{const e=window.PAGE_MODEL;if(!e?.propertyData)return null;const{propertyData:n}=e,t=n.address?.displayAddress||"",a=n.location;return{address:t,lat:a?.latitude??null,lng:a?.longitude??null,postcode:x(t)}}catch{return null}}function $(){try{const e=document.querySelectorAll('script[type="application/ld+json"]');for(const n of e){const t=JSON.parse(n.textContent||"");if(t["@type"]==="Product"||t["@type"]==="Place"){const a=t.geo,o=t.name||t.address?.streetAddress||"";if(a)return{address:o,lat:parseFloat(a.latitude),lng:parseFloat(a.longitude),postcode:x(o)}}}}catch{}return null}function I(){try{const e=['h1[itemprop="streetAddress"]','[data-test="address-label"]',".property-header-bedroom-and-price address","h1.property-header-address",'meta[property="og:title"]'];let n="";for(const r of e){const s=document.querySelector(r);if(s&&(n=s.getAttribute("content")||s.textContent?.trim()||"",n))break}const t=document.querySelector("[data-latitude][data-longitude]");let a=null,o=null;if(t&&(a=parseFloat(t.getAttribute("data-latitude")||""),o=parseFloat(t.getAttribute("data-longitude")||"")),!a||!o){const r=document.querySelector('iframe[src*="maps.google"]');if(r){const l=(r.getAttribute("src")||"").match(/q=([-\d.]+),([-\d.]+)/);l&&(a=parseFloat(l[1]),o=parseFloat(l[2]))}}return n?{address:n,lat:a&&!isNaN(a)?a:null,lng:o&&!isNaN(o)?o:null,postcode:x(n)}:null}catch{return null}}function F(){const e=H();if(e)return console.log("[PlanScope] Extracted data from Zoopla __NEXT_DATA__"),e;const n=V();if(n)return console.log("[PlanScope] Extracted data from Zoopla structured data"),n;const t=B();return t?(console.log("[PlanScope] Extracted data from Zoopla DOM"),t):(console.warn("[PlanScope] Could not extract Zoopla property data"),null)}function H(){try{const e=document.getElementById("__NEXT_DATA__");if(!e)return null;const t=JSON.parse(e.textContent||"")?.props?.pageProps;if(!t)return null;const a=t.listingDetails||t.listing||t.data?.listing;if(!a)return null;const o=a.address?.displayAddress||a.displayAddress||a.title||"",r=a.location||a.coordinates||a.latLng;return{address:o,lat:r?.lat??r?.latitude??null,lng:r?.lng??r?.lon??r?.longitude??null,postcode:a.address?.postcode||x(o)}}catch{return null}}function V(){try{const e=document.querySelectorAll('script[type="application/ld+json"]');for(const n of e){const t=JSON.parse(n.textContent||""),a=Array.isArray(t)?t:[t];for(const o of a)if(["Residence","Place","Product","Apartment","House"].includes(o["@type"])){const r=o.geo,s=o.address?.streetAddress||o.name||"";if(r)return{address:s,lat:parseFloat(r.latitude),lng:parseFloat(r.longitude),postcode:o.address?.postalCode||x(s)}}}}catch{}return null}function B(){try{const e=['[data-testid="address-label"]','h1[data-testid="listing-title"]',".dp-sidebar-wrapper__address","address",'[class*="Address"]','meta[property="og:title"]'];let n="";for(const r of e){const s=document.querySelector(r);if(s&&(n=s.getAttribute("content")||s.textContent?.trim()||"",n))break}let t=null,a=null;const o=document.querySelectorAll("[data-lat][data-lng], [data-latitude][data-longitude]");for(const r of o){const s=r.getAttribute("data-lat")||r.getAttribute("data-latitude"),l=r.getAttribute("data-lng")||r.getAttribute("data-longitude");if(s&&l){t=parseFloat(s),a=parseFloat(l);break}}if(!t||!a){const r=document.querySelectorAll("script:not([src])");for(const s of r){const l=s.textContent||"",d=l.match(/"lat(?:itude)?"\s*:\s*([-\d.]+)/),p=l.match(/"(?:lng|lon|longitude)"\s*:\s*([-\d.]+)/);if(d&&p){t=parseFloat(d[1]),a=parseFloat(p[1]);break}}}return n?{address:n,lat:t&&!isNaN(t)?t:null,lng:a&&!isNaN(a)?a:null,postcode:x(n)}:null}catch{return null}}const k={rightmove:/rightmove\.co\.uk\/properties\/\d+/,zoopla:/zoopla\.co\.uk\/(for-sale|to-rent)\/details\/\d+/};function W(e){return k.rightmove.test(e)?"rightmove":k.zoopla.test(e)?"zoopla":"unknown"}function j(e){switch(e){case"rightmove":return _();case"zoopla":return F();default:return null}}function U(){return`
    :host {
      all: initial;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      font-size: 14px;
      line-height: 1.5;
      color: #1f2937;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    .planscope-container {
      position: fixed;
      top: 80px;
      right: 16px;
      width: 380px;
      max-height: calc(100vh - 100px);
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #e5e7eb;
      transition: transform 0.3s ease, opacity 0.2s ease;
    }

    .planscope-container.collapsed {
      max-height: none;
    }

    .planscope-container.collapsed .planscope-body {
      display: none;
    }

    /* Header */
    .planscope-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      color: white;
      cursor: pointer;
      user-select: none;
    }

    .planscope-header:hover {
      background: linear-gradient(135deg, #5558e3, #7c4fe8);
    }

    .planscope-header-left {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .planscope-logo {
      width: 28px;
      height: 28px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 14px;
    }

    .planscope-title {
      font-weight: 600;
      font-size: 15px;
    }

    .planscope-toggle {
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s ease;
    }

    .planscope-container.collapsed .planscope-toggle {
      transform: rotate(180deg);
    }

    /* Body */
    .planscope-body {
      flex: 1;
      overflow-y: auto;
      max-height: calc(100vh - 200px);
    }

    /* Climate Summary */
    .planscope-climate {
      padding: 16px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .planscope-climate-title {
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #6b7280;
      margin-bottom: 12px;
    }

    .planscope-climate-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    .planscope-climate-stat {
      background: white;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #e5e7eb;
    }

    .planscope-climate-label {
      font-size: 11px;
      color: #6b7280;
      margin-bottom: 4px;
    }

    .planscope-climate-value {
      font-size: 18px;
      font-weight: 600;
      color: #1f2937;
    }

    .planscope-climate-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
    }

    .climate-pro {
      background: #dcfce7;
      color: #166534;
    }

    .climate-moderate {
      background: #fef3c7;
      color: #92400e;
    }

    .climate-restrictive {
      background: #fee2e2;
      color: #991b1b;
    }

    /* Filters */
    .planscope-filters {
      padding: 12px 16px;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .planscope-filter-btn {
      padding: 6px 12px;
      border-radius: 16px;
      border: 1px solid #d1d5db;
      background: white;
      font-size: 12px;
      cursor: pointer;
      transition: all 0.15s ease;
      color: #4b5563;
    }

    .planscope-filter-btn:hover {
      border-color: #6366f1;
      color: #6366f1;
    }

    .planscope-filter-btn.active {
      background: #6366f1;
      border-color: #6366f1;
      color: white;
    }

    /* Application List */
    .planscope-list {
      padding: 8px;
    }

    .planscope-list-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px;
      color: #6b7280;
      font-size: 12px;
    }

    /* Application Card */
    .planscope-card {
      padding: 12px;
      margin-bottom: 8px;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      transition: box-shadow 0.15s ease;
    }

    .planscope-card:hover {
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }

    .planscope-card-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 8px;
    }

    .planscope-card-status {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
    }

    .status-approved {
      background: #dcfce7;
      color: #166534;
    }

    .status-refused {
      background: #fee2e2;
      color: #991b1b;
    }

    .status-pending {
      background: #fef3c7;
      color: #92400e;
    }

    .status-withdrawn {
      background: #f3f4f6;
      color: #4b5563;
    }

    .planscope-card-distance {
      font-size: 12px;
      color: #6b7280;
    }

    .planscope-card-address {
      font-weight: 500;
      color: #1f2937;
      margin-bottom: 4px;
    }

    .planscope-card-summary {
      font-size: 13px;
      color: #4b5563;
      margin-bottom: 8px;
    }

    .planscope-card-meta {
      display: flex;
      gap: 12px;
      font-size: 11px;
      color: #6b7280;
    }

    .planscope-card-meta span {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    /* Map */
    .planscope-map-container {
      height: 200px;
      border-bottom: 1px solid #e5e7eb;
    }

    .planscope-map {
      width: 100%;
      height: 100%;
    }

    /* Insights */
    .planscope-insights {
      padding: 12px 16px;
      background: #fffbeb;
      border-bottom: 1px solid #fde68a;
    }

    .planscope-insight {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      padding: 8px 0;
      font-size: 13px;
    }

    .planscope-insight-icon {
      flex-shrink: 0;
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
    }

    .insight-positive .planscope-insight-icon {
      background: #dcfce7;
      color: #166534;
    }

    .insight-warning .planscope-insight-icon {
      background: #fee2e2;
      color: #991b1b;
    }

    .insight-info .planscope-insight-icon {
      background: #dbeafe;
      color: #1e40af;
    }

    /* Loading */
    .planscope-loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .planscope-spinner {
      width: 32px;
      height: 32px;
      border: 3px solid #e5e7eb;
      border-top-color: #6366f1;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 12px;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Error */
    .planscope-error {
      padding: 20px;
      text-align: center;
      color: #991b1b;
      background: #fee2e2;
    }

    /* Empty */
    .planscope-empty {
      padding: 40px 20px;
      text-align: center;
      color: #6b7280;
    }

    /* Scrollbar */
    .planscope-body::-webkit-scrollbar {
      width: 6px;
    }

    .planscope-body::-webkit-scrollbar-track {
      background: #f3f4f6;
    }

    .planscope-body::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 3px;
    }

    .planscope-body::-webkit-scrollbar-thumb:hover {
      background: #9ca3af;
    }

    /* Constraints */
    .planscope-constraints {
      padding: 12px 16px;
      background: #faf5ff;
      border-bottom: 1px solid #e9d5ff;
    }

    .planscope-constraints-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }

    .planscope-constraints-title {
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #6b7280;
    }

    .planscope-constraints-count {
      font-size: 11px;
      color: #8b5cf6;
      font-weight: 500;
    }

    .planscope-constraints-empty {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #9ca3af;
      font-size: 13px;
    }

    .planscope-constraints-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .planscope-constraint-group {
      background: white;
      border-radius: 6px;
      padding: 8px;
      border: 1px solid #e5e7eb;
    }

    .planscope-constraint-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: 4px;
      color: white;
      font-size: 11px;
      font-weight: 600;
      margin-bottom: 6px;
    }

    .planscope-constraint-icon {
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, 0.25);
      border-radius: 3px;
      font-size: 10px;
      font-weight: 700;
    }

    .planscope-constraint-label {
      flex: 1;
    }

    .planscope-constraint-count {
      background: rgba(255, 255, 255, 0.25);
      padding: 1px 5px;
      border-radius: 3px;
      font-size: 10px;
    }

    .planscope-constraint-details {
      padding-left: 4px;
    }

    .planscope-constraint-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 0;
      font-size: 12px;
      color: #4b5563;
      border-bottom: 1px solid #f3f4f6;
    }

    .planscope-constraint-item:last-child {
      border-bottom: none;
    }

    .planscope-constraint-name {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .planscope-constraint-grade {
      background: #fef3c7;
      color: #92400e;
      padding: 2px 6px;
      border-radius: 3px;
      font-size: 10px;
      font-weight: 600;
    }

    .planscope-constraint-link {
      color: #6366f1;
      text-decoration: none;
      font-size: 11px;
      font-weight: 500;
    }

    .planscope-constraint-link:hover {
      text-decoration: underline;
    }

    /* Compact constraint badges */
    .planscope-constraint-badges {
      display: flex;
      gap: 4px;
      margin-left: 8px;
    }

    .planscope-badge-mini {
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 3px;
      color: white;
      font-size: 10px;
      font-weight: 700;
    }

    /* Application URL Link */
    .planscope-card-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      color: #6366f1;
      text-decoration: none;
      font-size: 11px;
      font-weight: 500;
      margin-top: 8px;
    }

    .planscope-card-link:hover {
      text-decoration: underline;
    }

    /* Skeleton Loaders */
    @keyframes shimmer {
      0% {
        background-position: -200% 0;
      }
      100% {
        background-position: 200% 0;
      }
    }

    .planscope-skeleton {
      background: linear-gradient(
        90deg,
        #f3f4f6 25%,
        #e5e7eb 50%,
        #f3f4f6 75%
      );
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
      border-radius: 4px;
    }

    .planscope-skeleton-loading {
      padding: 16px;
    }

    .planscope-skeleton-climate {
      padding: 16px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .planscope-skeleton-title {
      height: 12px;
      width: 120px;
      margin-bottom: 12px;
    }

    .planscope-skeleton-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    .planscope-skeleton-stat {
      background: white;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #e5e7eb;
    }

    .planscope-skeleton-label {
      height: 10px;
      width: 60%;
      margin-bottom: 8px;
    }

    .planscope-skeleton-value {
      height: 20px;
      width: 40%;
    }

    .planscope-skeleton-filters {
      padding: 12px 16px;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      gap: 8px;
    }

    .planscope-skeleton-filter {
      height: 28px;
      width: 60px;
      border-radius: 16px;
    }

    .planscope-skeleton-list {
      padding: 8px;
    }

    .planscope-skeleton-card {
      padding: 12px;
      margin-bottom: 8px;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
    }

    .planscope-skeleton-card-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .planscope-skeleton-status {
      height: 22px;
      width: 70px;
      border-radius: 4px;
    }

    .planscope-skeleton-distance {
      height: 14px;
      width: 40px;
    }

    .planscope-skeleton-address {
      height: 16px;
      width: 80%;
      margin-bottom: 8px;
    }

    .planscope-skeleton-summary {
      height: 12px;
      width: 100%;
      margin-bottom: 4px;
    }

    .planscope-skeleton-summary-short {
      height: 12px;
      width: 60%;
    }

    /* Enhanced Error States */
    .planscope-error {
      padding: 24px 16px;
      text-align: center;
      background: #fef2f2;
      border-bottom: 1px solid #fecaca;
    }

    .planscope-error-icon {
      width: 48px;
      height: 48px;
      margin: 0 auto 12px;
      background: #fee2e2;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #dc2626;
      font-size: 24px;
    }

    .planscope-error-title {
      font-weight: 600;
      color: #991b1b;
      margin-bottom: 4px;
    }

    .planscope-error-message {
      font-size: 13px;
      color: #b91c1c;
      margin-bottom: 16px;
    }

    .planscope-error-retry {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      background: #dc2626;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s ease;
    }

    .planscope-error-retry:hover {
      background: #b91c1c;
    }

    /* Offline Banner */
    .planscope-offline-banner {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      background: #fef3c7;
      border-bottom: 1px solid #fde68a;
      font-size: 12px;
      color: #92400e;
    }

    .planscope-offline-icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    /* Cache Indicator */
    .planscope-cache-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 8px;
      background: #dbeafe;
      color: #1e40af;
      border-radius: 10px;
      font-size: 10px;
      font-weight: 500;
      margin-left: 8px;
    }

    /* Rate Limit Warning */
    .planscope-rate-limit {
      padding: 16px;
      background: #fff7ed;
      border-bottom: 1px solid #fed7aa;
      text-align: center;
    }

    .planscope-rate-limit-icon {
      font-size: 24px;
      margin-bottom: 8px;
    }

    .planscope-rate-limit-title {
      font-weight: 600;
      color: #c2410c;
      margin-bottom: 4px;
    }

    .planscope-rate-limit-message {
      font-size: 13px;
      color: #ea580c;
    }

    .planscope-rate-limit-timer {
      font-weight: 600;
      font-size: 18px;
      color: #c2410c;
      margin-top: 8px;
    }
  `}function q(e){const n=document.createElement("div");return n.className="planscope-header",n.innerHTML=`
    <div class="planscope-header-left">
      <div class="planscope-logo">P</div>
      <span class="planscope-title">PlanScope</span>
    </div>
    <div class="planscope-toggle">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </div>
  `,n.addEventListener("click",e),n}function G(e){const n=document.createElement("div");n.className="planscope-climate";const t=Z(e.planning_climate),a=J(e.planning_climate);return n.innerHTML=`
    <div class="planscope-climate-title">${c(e.name)} Planning Climate</div>
    <div class="planscope-climate-grid">
      <div class="planscope-climate-stat">
        <div class="planscope-climate-label">Approval Rate</div>
        <div class="planscope-climate-value">${T(e.approval_rate)}</div>
      </div>
      <div class="planscope-climate-stat">
        <div class="planscope-climate-label">Avg. Decision Time</div>
        <div class="planscope-climate-value">${e.avg_decision_days} days</div>
      </div>
      <div class="planscope-climate-stat" style="grid-column: span 2;">
        <div class="planscope-climate-label">Planning Climate</div>
        <span class="planscope-climate-badge ${t}">${a}</span>
      </div>
    </div>
  `,n}function Z(e){switch(e){case"PRO_DEVELOPMENT":return"climate-pro";case"MODERATE":return"climate-moderate";case"RESTRICTIVE":return"climate-restrictive"}}function J(e){switch(e){case"PRO_DEVELOPMENT":return"Pro-Development";case"MODERATE":return"Moderate";case"RESTRICTIVE":return"Restrictive"}}const X=[{value:"APPROVED",label:"Approved"},{value:"REFUSED",label:"Refused"},{value:"PENDING",label:"Pending"},{value:"WITHDRAWN",label:"Withdrawn"}];function K(e,n){const t=document.createElement("div");t.className="planscope-filters";for(const a of X){const o=document.createElement("button");o.className="planscope-filter-btn",o.textContent=a.label,e.status.includes(a.value)&&o.classList.add("active"),o.addEventListener("click",()=>{const r=e.status.includes(a.value)?e.status.filter(s=>s!==a.value):[...e.status,a.value];n({...e,status:r})}),t.appendChild(o)}return t}function Y(e){const n=document.createElement("div");n.className="planscope-card";const t=Q(e.status),a=ee(e.status),o=e.url?`<a href="${c(e.url)}" target="_blank" class="planscope-card-link">
        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
          <path d="M14 3.5V14H2V2h6.5V1H1.5A.5.5 0 001 1.5v13a.5.5 0 00.5.5h13a.5.5 0 00.5-.5V3.5a.5.5 0 00-.5-.5H14z"/>
          <path d="M9 1V0h7v7h-1V2.41L8.35 9.06l-.71-.71L14.29 2H10V1h-1z"/>
        </svg>
        View application
      </a>`:"";return n.innerHTML=`
    <div class="planscope-card-header">
      <span class="planscope-card-status ${t}">
        ${te(e.status)}
        ${a}
      </span>
      <span class="planscope-card-distance">${N(e.distance_m)}</span>
    </div>
    <div class="planscope-card-address">${c(e.address)}</div>
    <div class="planscope-card-summary">${c(e.summary)}</div>
    <div class="planscope-card-meta">
      <span>
        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
          <path d="M8 0C5.24 0 3 2.24 3 5c0 4.5 5 11 5 11s5-6.5 5-11c0-2.76-2.24-5-5-5zm0 7c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
        </svg>
        ${c(e.type)}
      </span>
      <span>
        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
          <path d="M14 2H2C.9 2 0 2.9 0 4v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM2 4h12v2H2V4zm0 10V8h12v6H2z"/>
        </svg>
        ${L(e.decision_date)}
      </span>
      <span>
        <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
          <path d="M8 0a8 8 0 100 16A8 8 0 008 0zm1 12H7V7h2v5zm0-6H7V4h2v2z"/>
        </svg>
        ${c(e.id)}
      </span>
    </div>
    ${o}
  `,n}function Q(e){switch(e){case"APPROVED":return"status-approved";case"REFUSED":return"status-refused";case"PENDING":return"status-pending";case"WITHDRAWN":return"status-withdrawn"}}function ee(e){switch(e){case"APPROVED":return"Approved";case"REFUSED":return"Refused";case"PENDING":return"Pending";case"WITHDRAWN":return"Withdrawn"}}function te(e){switch(e){case"APPROVED":return'<svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor"><path d="M6.5 12.5l-4-4 1.5-1.5 2.5 2.5 5.5-5.5 1.5 1.5-7 7z"/></svg>';case"REFUSED":return'<svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor"><path d="M12.5 4.5l-1-1L8 7l-3.5-3.5-1 1L7 8l-3.5 3.5 1 1L8 9l3.5 3.5 1-1L9 8l3.5-3.5z"/></svg>';case"PENDING":return'<svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 100 16A8 8 0 008 0zm1 9H7V4h2v5z"/></svg>';case"WITHDRAWN":return'<svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 100 16A8 8 0 008 0zm3 9H5V7h6v2z"/></svg>'}}function ne(e,n){const t=document.createElement("div");t.className="planscope-list";const a=ae(e,n),o=document.createElement("div");if(o.className="planscope-list-header",o.innerHTML=`
    <span>${a.length} application${a.length!==1?"s":""} found</span>
    <span>Within 500m</span>
  `,t.appendChild(o),a.length===0){const r=document.createElement("div");return r.className="planscope-empty",r.textContent=e.length>0?"No applications match your filters":"No planning applications found nearby",t.appendChild(r),t}for(const r of a)t.appendChild(Y(r));return t}function ae(e,n){let t=[...e];if(n.status.length>0&&(t=t.filter(a=>n.status.includes(a.status))),n.types.length>0&&(t=t.filter(a=>n.types.includes(a.type))),n.fromDate){const a=new Date(n.fromDate);t=t.filter(o=>o.decision_date?new Date(o.decision_date)>=a:!0)}if(n.toDate){const a=new Date(n.toDate);t=t.filter(o=>o.decision_date?new Date(o.decision_date)<=a:!0)}return t}const oe={APPROVED:"#22c55e",REFUSED:"#ef4444",PENDING:"#f59e0b",WITHDRAWN:"#6b7280"},se={"conservation-area":{label:"Conservation Area",color:"#8b5cf6",icon:"C"},"listed-building":{label:"Listed Building",color:"#ec4899",icon:"L"},"article-4-direction":{label:"Article 4 Direction",color:"#f97316",icon:"4"},"green-belt":{label:"Green Belt",color:"#22c55e",icon:"G"},"flood-risk-zone":{label:"Flood Risk Zone",color:"#3b82f6",icon:"F"},"tree-preservation-order":{label:"Tree Preservation Order",color:"#84cc16",icon:"T"},"ancient-woodland":{label:"Ancient Woodland",color:"#15803d",icon:"W"},"area-of-outstanding-natural-beauty":{label:"AONB",color:"#a855f7",icon:"A"},"national-park":{label:"National Park",color:"#14b8a6",icon:"N"},"scheduled-monument":{label:"Scheduled Monument",color:"#d97706",icon:"M"},"world-heritage-site":{label:"World Heritage Site",color:"#dc2626",icon:"H"}};let E=!1,g;const C="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",re="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";async function le(){if(E)return;const e=document.createElement("link");e.rel="stylesheet",e.href=C,document.head.appendChild(e),await new Promise((n,t)=>{const a=document.createElement("script");a.src=re,a.onload=()=>n(),a.onerror=t,document.head.appendChild(a)}),g=window.L,E=!0}async function ie(e,n,t,a){const o=document.createElement("div");o.className="planscope-map-container";const r=document.createElement("div");r.className="planscope-map",r.id="planscope-map-"+Date.now(),o.appendChild(r);try{await le();const s=document.createElement("link");s.rel="stylesheet",s.href=C,a.appendChild(s),requestAnimationFrame(()=>{requestAnimationFrame(()=>{ce(r,e,n,t)})})}catch(s){console.error("[PlanScope] Failed to load Leaflet:",s),r.innerHTML='<div style="padding: 20px; text-align: center; color: #6b7280;">Map unavailable</div>'}return o}function ce(e,n,t,a){if(!g)return;const o=g.map(e,{zoomControl:!0,scrollWheelZoom:!1}).setView([n,t],15);g.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"&copy; OpenStreetMap contributors",maxZoom:19}).addTo(o);const r=g.divIcon({className:"planscope-marker-property",html:`<div style="
      width: 24px;
      height: 24px;
      background: #1f2937;
      border: 3px solid white;
      border-radius: 50%;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    "></div>`,iconSize:[24,24],iconAnchor:[12,12]});g.marker([n,t],{icon:r}).addTo(o).bindPopup("This property");for(const s of a){const l=oe[s.status],d=g.divIcon({className:"planscope-marker-app",html:`<div style="
        width: 16px;
        height: 16px;
        background: ${l};
        border: 2px solid white;
        border-radius: 50%;
        box-shadow: 0 1px 3px rgba(0,0,0,0.3);
      "></div>`,iconSize:[16,16],iconAnchor:[8,8]});g.marker([s.lat,s.lng],{icon:d}).addTo(o).bindPopup(`
        <strong>${c(s.address)}</strong><br>
        ${c(s.summary)}<br>
        <em>${c(s.status)}</em>
      `)}if(a.length>0){const s=g.latLngBounds([[n,t],...a.map(l=>[l.lat,l.lng])]);o.fitBounds(s,{padding:[20,20]})}}function pe(e){const n=document.createElement("div");if(n.className="planscope-insights",e.length===0)return n;for(const t of e){const a=document.createElement("div");a.className=`planscope-insight insight-${t.type}`,a.innerHTML=`
      <div class="planscope-insight-icon">${de(t.type)}</div>
      <span>${c(t.message)}</span>
    `,n.appendChild(a)}return n}function de(e){switch(e){case"positive":return'<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 100 16A8 8 0 008 0zm-1 12l-3-3 1.5-1.5L7 9l4-4 1.5 1.5L7 12z"/></svg>';case"warning":return'<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0L0 14h16L8 0zm0 12a1 1 0 110-2 1 1 0 010 2zm1-3H7V5h2v4z"/></svg>';case"info":return'<svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 100 16A8 8 0 008 0zm1 12H7V7h2v5zm0-6H7V4h2v2z"/></svg>'}}function ue(e){const n=document.createElement("div");if(n.className="planscope-constraints",e.length===0)return n.innerHTML=`
      <div class="planscope-constraints-header">
        <span class="planscope-constraints-title">Planning Constraints</span>
      </div>
      <div class="planscope-constraints-empty">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M8 0a8 8 0 100 16A8 8 0 008 0zm1 12H7v-2h2v2zm0-3H7V4h2v5z"/>
        </svg>
        <span>No constraints found at this location</span>
      </div>
    `,n;const t=e.reduce((o,r)=>(o[r.type]||(o[r.type]=[]),o[r.type].push(r),o),{}),a=Object.keys(t);return n.innerHTML=`
    <div class="planscope-constraints-header">
      <span class="planscope-constraints-title">Planning Constraints</span>
      <span class="planscope-constraints-count">${e.length} found</span>
    </div>
    <div class="planscope-constraints-list">
      ${a.map(o=>{const r=se[o],s=t[o];return`
            <div class="planscope-constraint-group">
              <div class="planscope-constraint-badge" style="background-color: ${r.color}">
                <span class="planscope-constraint-icon">${r.icon}</span>
                <span class="planscope-constraint-label">${c(r.label)}</span>
                ${s.length>1?`<span class="planscope-constraint-count">${s.length}</span>`:""}
              </div>
              <div class="planscope-constraint-details">
                ${s.map(l=>`
                  <div class="planscope-constraint-item">
                    <span class="planscope-constraint-name">${c(l.name)}</span>
                    ${l.grade?`<span class="planscope-constraint-grade">Grade ${c(l.grade)}</span>`:""}
                    ${l.documentUrl?`<a href="${c(l.documentUrl)}" target="_blank" class="planscope-constraint-link">View</a>`:""}
                  </div>
                `).join("")}
              </div>
            </div>
          `}).join("")}
    </div>
  `,n}function ge(){const e=document.createElement("div");return e.className="planscope-skeleton-loading",e.innerHTML=`
    <!-- Climate Section Skeleton -->
    <div class="planscope-skeleton-climate">
      <div class="planscope-skeleton planscope-skeleton-title"></div>
      <div class="planscope-skeleton-grid">
        <div class="planscope-skeleton-stat">
          <div class="planscope-skeleton planscope-skeleton-label"></div>
          <div class="planscope-skeleton planscope-skeleton-value"></div>
        </div>
        <div class="planscope-skeleton-stat">
          <div class="planscope-skeleton planscope-skeleton-label"></div>
          <div class="planscope-skeleton planscope-skeleton-value"></div>
        </div>
        <div class="planscope-skeleton-stat">
          <div class="planscope-skeleton planscope-skeleton-label"></div>
          <div class="planscope-skeleton planscope-skeleton-value"></div>
        </div>
        <div class="planscope-skeleton-stat">
          <div class="planscope-skeleton planscope-skeleton-label"></div>
          <div class="planscope-skeleton planscope-skeleton-value"></div>
        </div>
      </div>
    </div>

    <!-- Filters Skeleton -->
    <div class="planscope-skeleton-filters">
      <div class="planscope-skeleton planscope-skeleton-filter"></div>
      <div class="planscope-skeleton planscope-skeleton-filter"></div>
      <div class="planscope-skeleton planscope-skeleton-filter"></div>
      <div class="planscope-skeleton planscope-skeleton-filter"></div>
    </div>

    <!-- Application Cards Skeleton -->
    <div class="planscope-skeleton-list">
      ${b()}
      ${b()}
      ${b()}
    </div>
  `,e}function b(){return`
    <div class="planscope-skeleton-card">
      <div class="planscope-skeleton-card-header">
        <div class="planscope-skeleton planscope-skeleton-status"></div>
        <div class="planscope-skeleton planscope-skeleton-distance"></div>
      </div>
      <div class="planscope-skeleton planscope-skeleton-address"></div>
      <div class="planscope-skeleton planscope-skeleton-summary"></div>
      <div class="planscope-skeleton planscope-skeleton-summary-short"></div>
    </div>
  `}function fe({error:e,onRetry:n}){const t=P(e),a=document.createElement("div");a.className="planscope-error";const o=me(t),r=he(t);if(a.innerHTML=`
    <div class="planscope-error-icon">${o}</div>
    <div class="planscope-error-title">${c(r)}</div>
    <div class="planscope-error-message">${c(t.userMessage)}</div>
    ${t.retryable?'<button class="planscope-error-retry">Try Again</button>':""}
  `,t.retryable&&n){const s=a.querySelector(".planscope-error-retry");s&&s.addEventListener("click",n)}return a}function me(e){switch(e.code){case"OFFLINE_ERROR":return"&#128268;";case"TIMEOUT_ERROR":return"&#9203;";case"RATE_LIMIT_ERROR":return"&#128683;";case"NETWORK_ERROR":return"&#127760;";default:return"&#9888;"}}function he(e){switch(e.code){case"OFFLINE_ERROR":return"You're Offline";case"TIMEOUT_ERROR":return"Request Timed Out";case"RATE_LIMIT_ERROR":return"Too Many Requests";case"NETWORK_ERROR":return"Connection Error";case"API_ERROR":return"Service Unavailable";case"PARSE_ERROR":return"Data Error";default:return"Something Went Wrong"}}function xe(){const e=document.createElement("div");return e.className="planscope-offline-banner",e.innerHTML=`
    <svg class="planscope-offline-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="1" y1="1" x2="23" y2="23"></line>
      <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"></path>
      <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"></path>
      <path d="M10.71 5.05A16 16 0 0 1 22.58 9"></path>
      <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"></path>
      <path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path>
      <line x1="12" y1="20" x2="12.01" y2="20"></line>
    </svg>
    <span>You're offline. Showing cached data.</span>
  `,e}function be(e,n){const t=[],a=ve(e),o=ye(e);n.approval_rate>=.7&&t.push({type:"positive",message:`${n.name} has a ${Math.round(n.approval_rate*100)}% approval rate - above average for planning applications.`});const r=e.filter(p=>p.status==="APPROVED"&&p.type==="EXTENSION");r.length>=3&&t.push({type:"positive",message:`${r.length} extension applications approved nearby - good precedent for similar works.`}),n.planning_climate==="PRO_DEVELOPMENT"&&t.push({type:"positive",message:"This area has a pro-development planning climate."}),n.avg_decision_days<=50&&t.push({type:"positive",message:`Average decision time is ${n.avg_decision_days} days - faster than many areas.`});const s=a.REFUSED/e.length;s>=.25&&e.length>=5&&t.push({type:"warning",message:`${Math.round(s*100)}% of nearby applications were refused - check local policies carefully.`}),n.planning_climate==="RESTRICTIVE"&&t.push({type:"warning",message:"This area has a restrictive planning climate - applications may face stricter scrutiny."}),n.approval_rate<.6&&t.push({type:"warning",message:`Low approval rate of ${Math.round(n.approval_rate*100)}% - consider professional advice.`});const l=e.filter(p=>p.status!=="REFUSED"||p.type!=="EXTENSION"||!p.decision_date?!1:Ee(new Date(p.decision_date))<=365);l.length>=2&&t.push({type:"warning",message:`${l.length} extension applications refused in the last year nearby.`}),n.avg_decision_days>=80&&t.push({type:"warning",message:`Average decision time is ${n.avg_decision_days} days - expect longer waits.`}),a.PENDING>=3&&t.push({type:"info",message:`${a.PENDING} applications pending nearby - area undergoing active development.`});const d=we(o);return d&&o[d]>=4&&t.push({type:"info",message:`${o[d]} ${ke(d)} applications nearby - common development pattern.`}),o.NEW_BUILD>=2&&t.push({type:"info",message:`${o.NEW_BUILD} new build applications nearby - area may be seeing significant change.`}),t.slice(0,5)}function ve(e){return e.reduce((n,t)=>(n[t.status]=(n[t.status]||0)+1,n),{})}function ye(e){return e.reduce((n,t)=>(n[t.type]=(n[t.type]||0)+1,n),{})}function we(e){let n=null,t=0;for(const[a,o]of Object.entries(e))o>t&&(n=a,t=o);return n}function ke(e){return e.toLowerCase().replace(/_/g," ")}function Ee(e){const t=new Date().getTime()-e.getTime();return Math.floor(t/(1e3*60*60*24))}function Se(e,n){const t=document.createElement("div");t.id="planscope-overlay-host";const a=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=U(),a.appendChild(o);const r=document.createElement("div");r.className="planscope-container",e.isOpen||r.classList.add("collapsed"),a.appendChild(r);let s={...e};const l=()=>{s.isOpen=!s.isOpen,r.classList.toggle("collapsed",!s.isOpen),n.onToggle(s.isOpen)},d=u=>{s.filters=u,n.onFilterChange(u)},p=()=>{n.onRetry&&n.onRetry()},v=q(l);r.appendChild(v);const i=document.createElement("div");i.className="planscope-body",r.appendChild(i);function y(){if(i.innerHTML="",s.isLoading){const u=ge();i.appendChild(u);return}if(s.error){const u=fe({error:s.error,onRetry:p});i.appendChild(u);return}if(s.data){if(!z()){const f=xe();i.appendChild(f)}const u=G(s.data.local_authority);if(i.appendChild(u),s.data.constraints){const f=ue(s.data.constraints);i.appendChild(f)}const w=be(s.data.applications,s.data.local_authority);if(w.length>0){const f=pe(w);i.appendChild(f)}if(s.data.applications.length>0){const f=s.data.applications.reduce((h,m)=>h+m.lat,0)/s.data.applications.length,D=s.data.applications.reduce((h,m)=>h+m.lng,0)/s.data.applications.length;ie(f,D,s.data.applications,a).then(h=>{const m=i.querySelector(".planscope-constraints")||i.querySelector(".planscope-climate");m&&m.nextSibling?i.insertBefore(h,m.nextSibling):i.insertBefore(h,i.children[2]||null)})}const A=K(s.filters,d);i.appendChild(A);const R=ne(s.data.applications,s.filters);i.appendChild(R)}else i.innerHTML=`
        <div class="planscope-empty">
          No data available
        </div>
      `}return y(),document.body.appendChild(t),console.log("[PlanScope] Overlay injected"),{update:u=>{s={...u},r.classList.toggle("collapsed",!s.isOpen),y()},destroy:()=>{t.remove(),console.log("[PlanScope] Overlay destroyed")}}}console.log("[PlanScope] Content script loaded");async function S(){const e=W(window.location.href);if(e==="unknown"){console.log("[PlanScope] Not on a supported property listing page");return}console.log(`[PlanScope] Detected site: ${e}`);const n=j(e);if(!n){console.warn("[PlanScope] Could not extract property data from page");return}console.log("[PlanScope] Property data:",n);const t={isOpen:sessionStorage.getItem("planscope_open")!=="false",isLoading:!0,error:null,data:null,filters:{status:[],types:[],fromDate:null,toDate:null}},a=Se(t,{onToggle:o=>{t.isOpen=o,sessionStorage.setItem("planscope_open",String(o))},onFilterChange:o=>{t.filters=o,a.update(t)}});if(n.lat&&n.lng)try{const o=await M(n.lat,n.lng,500);t.isLoading=!1,t.data=o,a.update(t),console.log("[PlanScope] Planning data loaded:",o)}catch(o){t.isLoading=!1,t.error=o instanceof Error?o.message:"Failed to load planning data",a.update(t),console.error("[PlanScope] Failed to fetch planning data:",o)}else t.isLoading=!1,t.error="Could not determine property location",a.update(t)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{S().catch(e=>console.error("[PlanScope] Initialization error:",e))}):S().catch(e=>console.error("[PlanScope] Initialization error:",e));
